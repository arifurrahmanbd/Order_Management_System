package com.newgen.hometheatre.controllers.admin;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {
    
    @RequestMapping("/dashboard")
    public String dashboard() {
        return "dashboard/dashboard";
    }
    @RequestMapping("/usermanager")
    public String welcome_view() {
        return "usermanager/createuser";
    }
    @RequestMapping("/login")
    public String login() {
        return "usermanager/login";
    }
    
}
