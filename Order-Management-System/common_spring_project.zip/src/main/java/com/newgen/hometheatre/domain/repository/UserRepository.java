package com.newgen.hometheatre.domain.repository;

import org.springframework.data.repository.CrudRepository;
import com.newgen.hometheatre.domain.entity.User;

public interface UserRepository extends CrudRepository<User, Long> {
	User findByUserEmailAndUserPassword(String userEmail, String userPassword);
	User findByUserEmail(String userEmail);
}