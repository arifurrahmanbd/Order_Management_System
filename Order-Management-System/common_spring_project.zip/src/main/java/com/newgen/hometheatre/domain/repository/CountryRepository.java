package com.newgen.hometheatre.domain.repository;

import org.springframework.data.repository.CrudRepository;
import com.newgen.hometheatre.domain.entity.Country;

public interface CountryRepository extends CrudRepository<Country, Long> {
	Country findByCountryName(String countryName);
}