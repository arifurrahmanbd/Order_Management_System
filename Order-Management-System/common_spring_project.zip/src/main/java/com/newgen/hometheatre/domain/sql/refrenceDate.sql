insert into hometheatre_db.ht_user(user_email, user_password) 
	values('admin@gmail.com', '123');
