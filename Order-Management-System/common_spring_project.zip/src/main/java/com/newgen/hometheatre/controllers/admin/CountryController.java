package com.newgen.hometheatre.controllers.admin;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.newgen.hometheatre.domain.repository.CountryRepository;
import com.newgen.hometheatre.domain.entity.Country;

@Controller
@RequestMapping(value = "/country")
public class CountryController {

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private EntityManager em;

	@RequestMapping(value = "", method = RequestMethod.GET)
	public String getCountryList(Model model) {

		model.addAttribute("countryList", countryRepository.findAll());

		return "admin/country";
	}
	@RequestMapping(value = "/countryList", method = RequestMethod.GET)
	public String getCountryListJson(Model model) {

		model.addAttribute("countryList", countryRepository.findAll());

		return "admin/countryList";
	}

	@RequestMapping(value = "/saveCountry", method = RequestMethod.POST)
	@ResponseBody
	public String saveCountry(HttpServletRequest request,
			HttpServletResponse response) {

		String id = request.getParameter("id");
		String countryName = request.getParameter("countryName");

		Country country = new Country();

		String status = "";

		if (id.equals("0") == true) {

			if (checkDuplicate(id, countryName) == true) {
				status = "[{\"status\" : \"Name already exists\"}]";
			} else {

				country.setCountryName(countryName);

				if (countryRepository.save(country) != null) {
					status = "[{\"status\" : \"Saved successfully\"}]";
				} else {
					status = "[{\"status\" : \"Error Occured\"}]";
				}
			}
		} else {

			if (checkDuplicate(id, countryName) == true) {
				status = "[{\"status\" : \"Name already exists\"}]";
			} else {
				country = countryRepository.findOne(Long.parseLong(id));

				country.setCountryName(countryName);

				if (countryRepository.save(country) != null) {
					status = "[{\"status\" : \"Updated successfully\"}]";
				} else {
					status = "[{\"status\" : \"Error Occured\"}]";
				}
			}
		}

		return status;
	}

	@RequestMapping(value = "/{id}/delete", method = RequestMethod.GET)
	public ModelAndView deleteCountry(@PathVariable long id) {
		countryRepository.delete(id);

		return new ModelAndView("redirect:/country");
	}

	@RequestMapping(value = "/getCountry", method = RequestMethod.POST)
	@ResponseBody
	public String getCountry(HttpServletRequest request,
			HttpServletResponse response) {
		String id = request.getParameter("id");

		Country country = new Country();

		country = countryRepository.findOne(Long.parseLong(id));
		String message = "";

		if (country != null) {
			message = "[{\"id\" : \"" + country.getId() + "\""
					+ ",\"countryName\" : \"" + country.getCountryName() + "\""
					+ "}]";
		}

		return message;
	}

	public Boolean checkDuplicate(String id, String countryName) {

		Boolean isDuplicate = false;

		if (id.equals("0") == true) {
			Country country = countryRepository.findByCountryName(countryName);

			if (country != null) {
				isDuplicate = true;
			}
		} else {

			CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
			CriteriaQuery<Country> c = criteriaBuilder
					.createQuery(Country.class);

			Root<Country> country = c
					.from(Country.class);
			Predicate predicateCondition = null;

			Predicate predCondCountryName = criteriaBuilder.equal(
					country.get("countryName"), countryName);
			Predicate predCondId = criteriaBuilder.notEqual(
					country.get("id"), id);

			predicateCondition = criteriaBuilder.and(predCondCountryName,
					predCondId);
			c.where(predicateCondition);

			List<Country> counrtyList = em
					.createQuery(c).getResultList();

			if (counrtyList.size() > 0) {
				isDuplicate = true;
			}
		}

		return isDuplicate;
	}
}
